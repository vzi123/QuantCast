package com.quantcast.framework;

import java.io.File;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

public interface Counting {
    List<String> apply();
}
