package com.quantcast.output;

public interface OutputWriter<T> {

	public void write(T output) ;
}
