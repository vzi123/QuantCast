package com.quantcast.exceptions;

public class InvalidCommandException extends Throwable {

    public static final long serialVersionUID = 1;

}
