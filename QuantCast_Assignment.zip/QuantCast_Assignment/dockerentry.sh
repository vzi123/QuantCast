#!/bin/sh
echo "Enter the command"
java -jar ./QuantCast_Assignment-2.3-SNAPSHOT.jar
echo "end"